# Wildlife Recognition Project

This project includes a React frontend and a FastAPI backend for wildlife image recognition.

## Structure

- `frontend/` - React app (to be added)
- `backend/` - FastAPI app for image prediction
