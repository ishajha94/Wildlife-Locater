# Wildlife Recognition Backend

FastAPI backend that runs wildlife recognition using YOLOv5.

## Setup

```bash
pip install -r requirements.txt
uvicorn wildlife_backend_api:app --reload
```
