# wildlife_backend_api.py
from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from PIL import Image
import io
import torch

app = FastAPI()

# Enable CORS for frontend communication
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load a pre-trained YOLOv5 model from Ultralytics (assumes torch.hub access)
model = torch.hub.load('ultralytics/yolov5', 'yolov5s', trust_repo=True)  # Lightweight model

@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    try:
        contents = await file.read()
        image = Image.open(io.BytesIO(contents)).convert("RGB")

        # Inference
        results = model(image)
        predictions = results.pandas().xyxy[0]

        # Convert predictions to desired format
        output = []
        for _, row in predictions.iterrows():
            output.append({
                "label": row['name'],
                "confidence": float(row['confidence'])
            })

        return {"predictions": output}

    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})
